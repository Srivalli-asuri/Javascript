let img_ele=document.getElementById("img")

let timerid=setTimeout(
    function(){
        img.src="https://static.vecteezy.com/system/resources/thumbnails/027/292/462/small_2x/bomb-explosion-with-fire-flames-and-smoke-isolated-on-transparent-background-png.png"
    },20000
)

let h2_ele=document.createElement("h2")
h2_ele.textContent="What is the Output of 3+4 :"
document.body.appendChild(h2_ele)

let input_ele=document.createElement("input")
input_ele.id="inp"
document.body.appendChild(input_ele)

let submit_btn=document.createElement("button")
submit_btn.textContent="Save your country"

submit_btn.id="btn"

submit_btn.onclick=function(){
    if (input_ele.value==7){
        clearTimeout(timerid)
    }
}
document.body.appendChild(submit_btn)